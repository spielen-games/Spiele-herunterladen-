import { FC } from "react";
import { Download } from "lucide-react";

interface GameCardProps {
  title: string;
  image: string;
  downloads: number;
  rating: number;
  version: string;
  description: string;
}

const GameCard: FC<GameCardProps> = ({ title, image, downloads, rating, version, description }) => {
  const handleDownload = () => {
    window.open("https://smrturl.co/a/s39ffb0e84e/497?s1=", "_blank");
  };

  return (
    <div className="game-card fade-in">
      <div className="flex items-start gap-4">
        <img
          src={image}
          alt={title}
          className="h-20 w-20 rounded-lg object-cover shadow-md hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />
        <div className="flex flex-col flex-1">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-lg">{title}</h3>
            <span className="rating-chip bg-blue-100 text-blue-700 animate-in fade-in-50 duration-500">★ {rating}</span>
          </div>
          <p className="text-sm text-gray-600 mt-1 line-clamp-2">{description}</p>
          <div className="flex items-center gap-2 mt-2">
            <span className="download-count bg-gray-100 px-2 py-1 rounded-full">
              {downloads.toLocaleString('de-DE')} تحميل
            </span>
            <span className="text-xs text-muted-foreground">الإصدار: {version}</span>
          </div>
          
          <div className="mt-4 flex items-center justify-between">
            <div className="flex gap-2">
              <img src="/ios-icon.svg" alt="iOS" className="platform-icon" />
              <img src="/android-icon.svg" alt="Android" className="platform-icon" />
            </div>
            <button 
              onClick={handleDownload} 
              className="download-button group"
            >
              <Download className="mr-2 h-4 w-4 group-hover:animate-bounce" />
              تحميل
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GameCard;