import { useEffect, useState } from "react";
import GameCard from "@/components/GameCard";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const games = [
  {
    title: "Minecraft",
    image: "/lovable-uploads/4d71b282-3073-4626-ba27-17a81170209e.png",
    downloads: 892456,
    rating: 4.9,
    version: "1.19.2",
    description: "عالم مفتوح للإبداع والبناء والمغامرة"
  },
  {
    title: "GTA 5 Mobile",
    image: "/lovable-uploads/22fa2985-72c4-47f3-a644-f2ac0339e876.png",
    downloads: 640779,
    rating: 4.7,
    version: "3.2.1",
    description: "لعبة عالم مفتوح مليئة بالمغامرات والإثارة في مدينة لوس سانتوس"
  },
  {
    title: "FIFA 23 Mobile",
    image: "/lovable-uploads/6606227e-9d93-4ef8-a19c-131870249b91.png",
    downloads: 359415,
    rating: 4.9,
    version: "2.4.1",
    description: "أفضل محاكاة لكرة القدم مع أحدث الفرق واللاعبين"
  }
];

const Index = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("rating");
  
  useEffect(() => {
    document.title = "تحميل ألعاب الموبايل";
  }, []);

  const filteredAndSortedGames = games
    .filter(game => 
      game.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      game.description.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => {
      if (sortBy === "rating") return b.rating - a.rating;
      if (sortBy === "downloads") return b.downloads - a.downloads;
      return 0;
    });

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">ألعاب الموبايل</h1>
          <p className="text-muted-foreground">
            حمّل ألعابك المفضلة على iOS و Android
          </p>
        </header>

        <div className="max-w-3xl mx-auto mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="relative flex-1 w-full">
              <Search className="absolute right-3 top-2.5 h-5 w-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="ابحث عن لعبة..."
                className="pr-10 text-right"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="ترتيب حسب" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="rating">التقييم</SelectItem>
                <SelectItem value="downloads">التحميلات</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid gap-6 md:gap-8 max-w-3xl mx-auto">
          {filteredAndSortedGames.map((game) => (
            <GameCard key={game.title} {...game} />
          ))}
        </div>

        <footer className="mt-16 text-center text-sm text-muted-foreground">
          <p>© 2024 ألعاب الموبايل. جميع الحقوق محفوظة.</p>
        </footer>
      </div>
    </div>
  );
};

export default Index;